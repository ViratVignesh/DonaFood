package com.example.sahara

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
